
from django.conf.urls import url,include
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

#导入对应APP的views视图文件，Test_Report是APP名称，导入APP的views文件
from Test_Report import views

#引号中的正则表达式和后面的业务逻辑函数
urlpatterns = [
    url(r'^Search$', views.showSearch),
    url(r'^Report$', views.Report),

]

urlpatterns += staticfiles_urlpatterns()














