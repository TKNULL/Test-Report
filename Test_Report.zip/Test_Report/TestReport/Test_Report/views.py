
# -*- coding: utf-8 -*-
from django.shortcuts import render,render_to_response
from django.shortcuts import HttpResponseRedirect,Http404,HttpResponse,render_to_response
from django.shortcuts import render
from django.shortcuts import *
from bs4 import BeautifulSoup
import requests
import re
import pymysql
import os
import json


#一、用户请求http://127.0.0.1:8000/Search，返回Search界面便于用户输入【版本号】【测试项】【上报者邮箱】
def showSearch(request):
    if request.method == 'GET':
        data = {
        "product":"MEIOS4",
        "function":"getComponentAndVersion"
        }
        #PHP接口，传入指定数据向接口发送请求，返回信息。
        r = requests.post('http://xxx.xx.xx.xx:81/getdata.php', data=data)
        return render(request,"Search.html",{"SELECTOR":json.loads(r.text),})
        #返回html文件用render(),第一个参数固定，第二个参数是指定返回的文件


#二、 Search.html界面输入子产品、版本、意见提交人邮箱，返回Report.html
def Report(request):
    #1、先获取用户传输的参数
    if request.method=="POST":
        print("获取用户传入的参数")
        inputComponent = request.POST.get('inputComponent',None)
        inputVersion = request.POST.get('inputVersion',None)
        testItem=request.POST.get('testItem',None)
        inputcommenter = request.POST.get('inputcommenter',None)


    #2、传入参数，向服务器发送请求，获取字段转成HTML页面
    data = {
        #变量
        "component":inputComponent,
        "version":inputVersion,
        "commenter":inputcommenter,

        #默认选择手机产品,MEIOS4
        "product":"MEIOS4",
        "classification":"手机产品",
        #bug页面显示的字段
        'columnlist':"product,component,assigned_to,bug_status,resolution,short_desc,changeddate,cf_imei,bug_severity,cf_type"
    }
    get_data = requests.post('http://xxx.xx.xx.xx:81/getdata.php', data=data)

    #3、服务器获取的字段写入html
    html_name = inputComponent + inputVersion + '.html'
    #html_name = "Gist"+'.html'
    htmlfile = open(html_name,"w",encoding='utf-8')#以写方式打开,如果文件不存在则创建文件,同时指定编码，兼容PY3
    htmlfile.write(get_data.text)#写入数据
    htmlfile.close()

    #4、打开html文件，实例化BS对象
    htmlfile = open(html_name, 'r',encoding='utf-8')
    htmlpage = htmlfile.read()
    soup = BeautifulSoup(htmlpage, "html.parser")

    #5、清洗并储存数据
    #搜索到的bug总数量
    bz_result_count=soup.select(".bz_result_count")
    bz_result_count = " ".join('%s' %id for id in bz_result_count)#列表格式转换成字符串,便于分割出bug数量
    bz_list=re.split(">", bz_result_count)          #以>分割
    bz_list=re.split(" ",bz_list[1])            #以" "分割

    #定义数组存储数据
    bz_id=[] #89199
    bz_assigned_to =[]
    bz_bug_status = []
    bz_resolution= []
    bz_title= []
    bz_url = []
    bz_imei= []
    bz_bug_severity = []
    bz_cf_type = []

    #获取负责人
    bugAssigneeInfo = soup.select(".bz_assigned_to_column")
    for bugAssignee in bugAssigneeInfo:
        bz_assigned_to.append(bugAssignee.span.get_text().strip())

    #获取bug标题、URL、bugID
    bzTitle=[]
    bz_desc=soup.select(".bz_short_desc_column")
    for desc in bz_desc:
        bz_url.append(desc.a["href"])#url链接
        bzTitle.append(desc.a.get_text().strip())#bug标题

    # #获取bugID
    for bugiD in bz_url:
        ID=bugiD.split('=',1)
        bz_id.append(ID[1])

    #两个列表拼接成bug标题
    for i in range(len(bz_id)):
        bz_title.append(bz_id[i]+bzTitle[i])


    #获取IMEI
    imeis=soup.select(".bz_cf_imei_column")
    for imei in imeis:
        if(imei.get_text().strip()[-5:]==""):
            bz_imei.append("null!")  #如果没有imei的话，填写null
        else:
            bz_imei.append(imei.get_text().strip()[-5:])

    #根据IMEI获取当前测试设备个数
    phone_num=list(set(imeis))

    #获取严重程度
    bug_severitys = soup.findAll('td',{"class":"bz_bug_severity_column"})
    for bug_severity in bug_severitys:
        infos = bug_severity.findAll('span')
        for info in infos:
            severity =info.string.strip()
            bz_bug_severity.append(severity)

    #获取异常类型，并把“---”替换成“其他”
    cf_type=[]   #创建一个空数组，先暂时保存未处理的类型
    bz_cf_types =soup.select(".bz_cf_type_column")
    for type in bz_cf_types:
        cf_type.append(type.get_text().strip())
    other_type=["---"]
    bz_cf_type =["其他" if x in other_type else x for x in cf_type]

    #获取Subm
    bug_status=soup.select(".bz_bug_status_column")
    for infos in bug_status:
        info=infos.findAll("span")
        for inf in info:
            statu=inf.string.strip()
            status=statu.split('(')[:1]
            bz_bug_status.append(status)

    #获取DUPL
    resolution = soup.select(".bz_resolution_column")
    for resol in resolution:
        infos = resol.findAll("span")
        for info in infos:
            resolution=info.string.strip()
            bz_resolution.append(resolution)

    #创建与bug数量相同长度的列表，方便组合传参
    Component=[]
    Version=[]
    TestItem=[]
    for i in range(len(bz_resolution)):
        Component.append(inputComponent)
        Version.append(inputVersion)
        TestItem.append(testItem)

    #6、数据项组合,存储到对应的列表
    #bug详细信息
    ALL_BUGS = []
    all_bugs=list(zip(bz_title,bz_imei,bz_bug_severity,bz_cf_type,bz_bug_severity,bz_bug_status,bz_assigned_to, Component,Version,TestItem,))
    #创建一个列表，用于当作字典的键
    bugListKey=["bz_title","IMEI","severity","type","time","status","assigned_to","Component","Version","TestItem"]
    for i in all_bugs:
        bugList=dict(zip(bugListKey,i))
        ALL_BUGS.append(bugList)

    #数据格式
    #[{'bz_title': '88888【性能测试】测试出现XXXXXXXXXXXXXXXXXXXXXXX', 'IMEI': '09664', 'severity': 'S1-致命', 'type': '死机', 'time': 'S1-致命', 'status': ['已解决 '], 'assigned_to': 'hzx', 'Component': 'XXAPP', 'Version': 'r12345（XXAPP）', 'TestItem': '性能测试'},
    # {'bz_title': '77777【性能测试】测试出现XXXXXXXXXXXXXXXXXXXXXXX', 'IMEI': '19606', 'severity': 'S1-致命', 'type': '崩溃', 'time': 'S1-致命', 'status': ['已解决 '], 'assigned_to': 'hzx', 'Component': 'XXAPP', 'Version': 'r12345（XXAPP）', 'TestItem': '性能测试'},
    # {'bz_title': '66666【性能测试】测试出现XXXXXXXXXXXXXXXXXXXXXXX', 'IMEI': '03485', 'severity': 'S1-致命', 'type': '功能失效', 'time': 'S1-致命', 'status': ['重新开启'], 'assigned_to': 'lsg', 'Component': 'XXAPP', 'Version': 'r12345（XXAPP）', 'TestItem': '性能测试'},
    # {'bz_title': '55555【性能测试】测试出现XXXXXXXXXXXXXXXXXXXXXXX', 'IMEI': 'null!', 'severity': 'S3-普通', 'type': 'UI不符', 'time': 'S3-普通', 'status': ['已关闭'], 'assigned_to': 'csy1', 'Component': 'XXAPP', 'Version': 'r12345（XXAPP）', 'TestItem': '性能测试'}]

    return render(request,"report.html",{"bug":json.dumps(ALL_BUGS,ensure_ascii=False),})









# ~#===========================================================================================
# 程序主入口
if __name__ == '__main__':
    showSearch(request)



