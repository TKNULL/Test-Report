from django.apps import AppConfig


class ReportConfig(AppConfig):
    name = 'Test_Report'
