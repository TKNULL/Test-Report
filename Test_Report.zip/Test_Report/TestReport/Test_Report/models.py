from django.db import models
#from Test_Report.models import autoreport

#1、选择要操作的数据； 2、继承models.Model类
#一个模型类代表数据库中的一个表，一个模型类的实例代表这个数据库中的一条特定的记录
# class AutoReport(models.Model):
#      IMEI=models.CharField(max_length=100)
#      classification=models.CharField(max_length=100)  #类型是char
#      product=models.CharField(max_length=100)
#      component=models.CharField(max_length=100)
#      version=models.CharField(max_length=100)
#      Newspaper=models.CharField(max_length=100)
#      bugID=models.CharField(max_length=100)
#      bugTitle=models.CharField(max_length=100)
#      bugURL=models.CharField(max_length=100)
#      bugType=models.CharField(max_length=100)
#      Importance=models.CharField(max_length=100)
#      state=models.CharField(max_length=100)
#      Handler=models.CharField(max_length=100)
#      Resolution=models.CharField(max_length=100)
