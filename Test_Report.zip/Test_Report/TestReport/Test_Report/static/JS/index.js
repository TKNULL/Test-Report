/**
 * Created by Gist on 2018/8/1，search.html背景展示
 */
var nav = document.getElementById("nav");
	var scrollTop = 0;
	window.onscroll=function(){
		//document.body.scrollTop 网页被卷去的高
		//document.documentElement.scrollTop  滚动条的位置
		scrollTop=document.body.scrollTop || document.documentElement.scrollTop;
		console.log(scrollTop)
		if(scrollTop > 300){
			document.getElementById('nav').style.backgroundColor="rgb(244,244,244)";
		}else{
			document.getElementById('nav').style.backgroundColor="rgba(0,0,0,0)";
		//设置表格自适应字体
		//var maxHeight =3rem
		//var trSize = document.getElementsByClassName("testInfo").getElementsByTagName("td");

		}
	};
/**
 * Created by Gist on 2018/8/15,JS动态创建表格，ajax填入数据
 */
var  bug =[
	{bugID:"89199",bugTitle:"【Monkey】【图库】不安装TOP50执行系", IMEI:"12345", bugURL:"bugURL",bugType:"重启4", Importance:"重启3",state:"重启"},
	{bugID:"88888",bugTitle:"【Monkey】【图库】不安装TOP50执行系", IMEI:"65432", bugURL:"bugURL",bugType:"重启4", Importance:"重启3",state:"重启"},
	{bugID:"77777",bugTitle:"【Monkey】【图库】不安装TOP50执行系", IMEI:"54321", bugURL:"bugURL",bugType:"重启4", Importance:"重启3",state:"重启"},
	{bugID:"66666",bugTitle:"【Monkey】【图库】不安装TOP50执行系", IMEI:"45678", bugURL:"bugURL",bugType:"重启4", Importance:"重启3",state:"重启"}
	];

window.onload = function(){

	alert("!!!!!!!!!!!!!!!!!!!!!!!!");


	var ajaxBugInfo = document.getElementById("ajaxBugInfo");
	for (var i =0; i<bug.length; i++){ //遍历ajax获取到的json数据
		var trow = getDataRow(bug[i]); //定义一个方法，返回tr数据
		tbody.appendChild(trow)
	}
	function  getDataRow(h){
		var row = document.createElement("tr"); //创建一行，存储一组数据
		var bugId =document.createElement("td"); //创建列
		bugId.innerHTML = h.bugID;  //填入数据
		row.appendChild(bugId);   //加入行

		var bugtitle = document.createElement("td");
		bugtitle.innerHTML = h.bugTitle;
		row.appendChild(row);

		var imei = document.createElement("td");
		bugtitle.innerHTML = h.IMEI;
		row.appendChild(row);
		var bugurl = document.createElement("td");
		bugtitle.innerHTML = h.bugURL;
		row.appendChild(row);
		var bugtype = document.createElement("td");
		bugtitle.innerHTML = h.bugType;
		row.appendChild(row);
		var importance = document.createElement("td");
		bugtitle.innerHTML = h.Importance
		row.appendChild(row);
		var State = document.createElement("td");
		bugtitle.innerHTML = h.state();
		row.appendChild(row);

		return row;
	}
};






































